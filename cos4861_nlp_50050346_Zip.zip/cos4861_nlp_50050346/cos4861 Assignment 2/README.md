# COS4861 

This is the NLP COS4861 skeleton. New classes and test cases will be placed here for you to incorporate into your code base.

# Release 1
In this initial release:
1. Tokenizer
- MLE
- EditDistance.

Download the assignment instructions for assignment 1, complete the missing sections, create a private repo for your 
assignment, and add the lecturer's user as a developer.

Instructions for adding changes to this repo to your own will be provided in due course.

## Bugfixes
1. Fixed calculation errors in MLE test cases

